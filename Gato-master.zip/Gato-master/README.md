# Gato
Juego del gato en C#


se requiera una aplicación en donde se pueda jugar el juego: “el gato “
Que el juego permita jugar el juego, bajo el siguiente criterio
- el sistema solicitará la posición (Ingrese una fila, Ingrese una columna)
.-el sistema validara que no exista valor en esa posición, en caso de que ya exista, notificará al usuario y volverá a solicitar el valor 
.-cada que ingresen un nuevo valor, mostrar los datos en pantalla
- Gana el jugador que logre poner 3 figuras en una línea (vertical, horizontal o diagonal). 
- En el caso de que se ocupen todas las casillas y ningún jugador haya realizado una línea recta, se declara empate.

Actualizado 4 de Octubre del 2016 Nuevas funcionalidades:(Versión 1.6)
- Permitir continuar jugando
- Permitir guardar  score
- Perrmitir conexión a mysql para guardar registro del score
- Mostrar Score
- Crear apartado para mostrar score

[Revisar documentación](https://github.com/NeftaliAcosta/Gato/wiki/Funciones)

Mas detalles: https://neftaliacosta.com/codigo-juego-gato-c-sharp/
